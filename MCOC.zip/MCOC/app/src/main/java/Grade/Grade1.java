import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mcoc.R;

public class Grade1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade1);
    }
}